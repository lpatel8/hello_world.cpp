#include<iostream>
  
  int main()
  {
  std:: count<"hello_world!">;
  return 0;
  }
